package com.example.javawebapp.forms;

import org.hibernate.validator.constraints.br.CPF;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class CadastroClienteForm {

    @NotNull
    @NotBlank
    private String nome;
    @NotNull
    @NotBlank
    @CPF
    private String cpf;
    @NotNull
    @NotBlank
    private String telefone;
    
    @NotNull
    @NotBlank
    @Email
    private String email;
    @NotNull
    @NotBlank
    @Size(min = 8, max = 20)
    private String senha;
    
    public CadastroClienteForm(String nome, String cpf, String telefone, String email, String senha) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    

    // @NotNull 
    // @NotBlank
    // private String nome;
    // @NotNull 
    // @NotBlank 
    // @Email
    // private String email;
    // @NotNull 
    // @NotBlank 
    // @Size(min = 3, max = 20)
    // private String senha;

    //validar senha
    // if (senha == null || senha.isEmpty()) {
    //     erros.add("A senha não pode ser vazia");
    // }

    // if (senha.length() < 8 || senha.length() > 20) {
    //     erros.add("A senha deve ter de 8 a 20 caracteres");
    // }

    // if (!Pattern.compile("[a-z]").matcher(senha).find()) {
    //     erros.add("A senha deve ter pelo menos uma letra minúscula");
    // }

    // if (!Pattern.compile("[A-Z]").matcher(senha).find()) {
    //     erros.add("A senha deve ter pelo menos uma letra maiúscula");
    // }

    // if (!Pattern.compile("[0-9]").matcher(senha).find()) {
    //     erros.add("A senha deve ter pelo menos um número");
    // }

    // if (!verificaCaracteresEspeciais(senha)) {
    //     erros.add("A senha deve ter pelo menos um caracter especial");
    // }
    
    // //validar confirmacao da senha
    // if (confirmar_senha == null || confirmar_senha.isBlank()) {
    //     erros.add("A confirmação da senha não pode ser vazia");
    // }
    // if (confirmar_senha != senha) {
    //     erros.add("A confirmação da senha deve ser igual a primeira senha");
    // }
}
