package com.example.javawebapp;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Set;

import com.example.javawebapp.forms.CadastroMotoristaForm;
import com.example.javawebapp.usuario.MotoristaDao;
import com.example.javawebapp.validators.ValidatorUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolation;

@WebServlet(name = "cadastroServlet", value = "/cadastroMotorista")
public class CadastroMotoristaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        req.getRequestDispatcher("WEB-INF/motorista.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String cpf = req.getParameter("cpf");
        String nome = req.getParameter("nome");
        String telefone = req.getParameter("telefone");
        String email = req.getParameter("email");
        String senha = req.getParameter("senha");
        String registro = req.getParameter("registro");
        String categoria = req.getParameter("categoria");
        LocalDate data_emissao = LocalDate.parse(req.getParameter("data_emissao"));

        CadastroMotoristaForm cadastroMotoristaForm = new CadastroMotoristaForm(nome, cpf, telefone, email, senha, registro, categoria, data_emissao);
        
        Set<ConstraintViolation<CadastroMotoristaForm>> violations = ValidatorUtil.validateObject(cadastroMotoristaForm);
        
        if (violations.isEmpty()) {
            if (MotoristaDao.existeComEmail(email)) {
                // mandar erro na tela
                req.setAttribute("existeErro", "Já existe um usuário com esse e-mail");
                req.getRequestDispatcher("WEB-INF/cadastro.jsp").forward(req, res);
            } else {
                MotoristaDao.cadastrar(nome, cpf, telefone, email, senha, data_emissao, categoria, registro);
                res.sendRedirect("login");
            }
        } else {
            req.setAttribute("cadastroForm", cadastroMotoristaForm);
            req.setAttribute("violations", violations);
            req.getRequestDispatcher("WEB-INF/cadastro.jsp").forward(req, res);
        }
    }
    
   
}
