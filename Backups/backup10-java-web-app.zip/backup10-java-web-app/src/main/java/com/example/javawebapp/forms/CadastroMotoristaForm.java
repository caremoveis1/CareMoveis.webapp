package com.example.javawebapp.forms;

import java.time.LocalDate;

import org.hibernate.validator.constraints.br.CPF;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class CadastroMotoristaForm {
    @NotNull
    @NotBlank
    private String nome;
    @NotNull
    @NotBlank
    @CPF
    private String cpf;
    @NotNull
    @NotBlank
    private String telefone;
    
    @NotNull
    @NotBlank
    @Email
    private String email;
    @NotNull
    @NotBlank
    @Size(min = 8, max = 20)
    private String senha;

    // @NotNull
    // @NotBlank
    // private String conta;
    // @NotNull
    // @NotBlank
    // private String agencia;
    // @NotNull
    // @NotBlank
    // private String nome_titular; 
    // @NotNull
    // @NotBlank
    // @CPF
    // private String cpf_titular;

    @NotNull
    @NotBlank
    @Size(max = 10)
    private String numero_cnh;
    @NotNull
    @NotBlank
    private String categoria_cnh;
    @NotNull
    @NotBlank
    private LocalDate data_emissao_cnh;
    // @NotNull
    // @NotBlank
    // private Date data_validade_cnh;
    public CadastroMotoristaForm(String nome, String cpf, String telefone, String email, String senha, String numero_cnh, String categoria_cnh, LocalDate data_emissao) {
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;

        this.email = email;
        this.senha = senha;

        // this.conta = conta;
        // this.agencia = agencia;
        // this.nome_titular = nome_titular;
        // this.cpf_titular = cpf_titular;
        
        this.numero_cnh = numero_cnh;
        this.categoria_cnh = categoria_cnh;
        this.data_emissao_cnh = data_emissao;
        // this.data_validade_cnh = data_validade_cnh;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public String getTelefone() {
        return telefone;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getSenha() {
        return senha;
    }
    public void setSenha(String senha) {
        this.senha = senha;
    }
    // public String getConta() {
    //     return conta;
    // }
    // public void setConta(String conta) {
    //     this.conta = conta;
    // }
    // public String getAgencia() {
    //     return agencia;
    // }
    // public void setAgencia(String agencia) {
    //     this.agencia = agencia;
    // }
    // public String getNome_titular() {
    //     return nome_titular;
    // }
    // public void setNome_titular(String nome_titular) {
    //     this.nome_titular = nome_titular;
    // }
    // public String getCpf_titular() {
    //     return cpf_titular;
    // }
    // public void setCpf_titular(String cpf_titular) {
    //     this.cpf_titular = cpf_titular;
    // }
    public String getNumero_cnh() {
        return numero_cnh;
    }
    public void setNumero_cnh(String numero_cnh) {
        this.numero_cnh = numero_cnh;
    }
    public String getCategoria_cnh() {
        return categoria_cnh;
    }
    public void setCategoria_cnh(String categoria_cnh) {
        this.categoria_cnh = categoria_cnh;
    }
    public LocalDate getData_emissao_cnh() {
        return data_emissao_cnh;
    }
    public void setData_emissao_cnh(LocalDate data_emissao_cnh) {
        this.data_emissao_cnh = data_emissao_cnh;
    }
    // public Date getData_validade_cnh() {
    //     return data_validade_cnh;
    // }
    // public void setData_validade_cnh(Date data_validade_cnh) {
    //     this.data_validade_cnh = data_validade_cnh;
    // }

    //validar senha
    // if (senha == null || senha.isEmpty()) {
    //     erros.add("A senha não pode ser vazia");
    // }

    // if (senha.length() < 8 || senha.length() > 20) {
    //     erros.add("A senha deve ter de 8 a 20 caracteres");
    // }

    // if (!Pattern.compile("[a-z]").matcher(senha).find()) {
    //     erros.add("A senha deve ter pelo menos uma letra minúscula");
    // }

    // if (!Pattern.compile("[A-Z]").matcher(senha).find()) {
    //     erros.add("A senha deve ter pelo menos uma letra maiúscula");
    // }

    // if (!Pattern.compile("[0-9]").matcher(senha).find()) {
    //     erros.add("A senha deve ter pelo menos um número");
    // }

    // if (!verificaCaracteresEspeciais(senha)) {
    //     erros.add("A senha deve ter pelo menos um caracter especial");
    // }
    
    // //validar confirmacao da senha
    // if (confirmar_senha == null || confirmar_senha.isBlank()) {
    //     erros.add("A confirmação da senha não pode ser vazia");
    // }
    // if (confirmar_senha != senha) {
    //     erros.add("A confirmação da senha deve ser igual a primeira senha");
    // }
}
