package com.example.javawebapp.usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Statement;
import java.time.LocalDate;

import com.example.javawebapp.db.Conexao;

import at.favre.lib.crypto.bcrypt.BCrypt;

public class MotoristaDao {
    public static Motorista cadastrar(String cpf, String nome, String telefone, String email, String senha, LocalDate data_emissao, String registro, String categoria) {
        Motorista motorista = null;
        String hashSenha = BCrypt.withDefaults().hashToString(12, senha.toCharArray());
        String sql = "INSERT INTO Motorista_Cnh (cpf, nome, telefone, email, senha, data_emissao, registro, categoria) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";
        
        try (
            Connection connection = Conexao.getConnection();
            PreparedStatement statement = connection
                .prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
        ) {
            statement.setString(1, cpf);
            statement.setString(2, nome);
            statement.setString(3, telefone);
            statement.setString(4, email);
            statement.setString(5, hashSenha);
            statement.setObject(6, data_emissao);
            statement.setString(7, registro);
            statement.setString(8, categoria);
            statement.executeUpdate();

            ResultSet rs = statement.getGeneratedKeys();

            if(rs.next()) {
                motorista = new Motorista(cpf, nome, telefone, email, hashSenha, data_emissao, registro, categoria);
            }

            rs.close();

            return motorista;  
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List<Motorista> listarTodos() {
        String sql = "SELECT * FROM Motorista_Cnh;";
        List<Motorista> motoristas = new ArrayList<>();

        try (
            Connection connection = Conexao.getConnection();
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(sql);
        ) {
            while(rs.next()) {
                motoristas.add(
                    new Motorista(
                        rs.getString("cpf"), 
                        rs.getString("nome"), 
                        rs.getString("telefone"), 
                        rs.getString("email"),
                        rs.getString("senha"), 
                        (LocalDate) rs.getObject("data_emissao"), 
                        rs.getString("registro"), 
                        rs.getString("categoria")
                    )
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            return motoristas;
        } 

        return motoristas;
    }

     public static Motorista buscarPorCpf(String cpf) {
        String sql = "SELECT * FROM Motorista_Cnh WHERE id = ?;";

        try (
            Connection connection = Conexao.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
        ) {
            statement.setString(1, cpf);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                return new Motorista(
                    rs.getString("cpf"), 
                    rs.getString("nome"), 
                    rs.getString("telefone"), 
                    rs.getString("email"),
                    rs.getString("senha"), 
                    (LocalDate) rs.getObject("data_emissao"), 
                    rs.getString("registro"), 
                    rs.getString("categoria")
                );
            }

            rs.close();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return null;
    }

    public static Motorista buscarPorEmail(String email) {
        String sql = "SELECT * FROM Motorista_Cnh WHERE email = ?;";

        try (
            Connection connection = Conexao.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
        ) {
            statement.setString(1, email);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                return new Motorista(
                    rs.getString("cpf"), 
                    rs.getString("nome"), 
                    rs.getString("telefone"), 
                    rs.getString("email"),
                    rs.getString("senha"), 
                    (LocalDate) rs.getObject("data_emissao"), 
                    rs.getString("registro"), 
                    rs.getString("categoria")
                );
            }

            rs.close();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

        return null;
    }

    public static Boolean login(String email, String senha) {
        Motorista motorista = buscarPorEmail(email);
        if (motorista != null) {
            BCrypt.Result result = BCrypt.verifyer().verify(senha.toCharArray(), motorista.getSenha());
            return result.verified;
        }
        return false;
    }

    public static Boolean existeComEmail(String email) {
        return buscarPorEmail(email) != null;
    }
}   