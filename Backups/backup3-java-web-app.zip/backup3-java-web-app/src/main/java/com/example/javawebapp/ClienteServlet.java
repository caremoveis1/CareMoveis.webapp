package com.example.javawebapp;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name="cliente", value="/cliente")
public class ClienteServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        //Dados Pessoais Cliente
        String nome = req.getParameter("nome");
        String cpf = req.getParameter("cpf");
        String tel = req.getParameter("tel");

        //Dados de Acesso Cliente
        String email = req.getParameter("email");
        String senha = req.getParameter("senha");
        String confirmar_senha = req.getParameter("confirmar_senha");

        System.out.println("nome: " + nome);
        System.out.println("cpf: " + cpf);
        System.out.println("telefone: " + tel);

        System.out.println("email: " + email);
        System.out.println("senha: " + senha);
        System.out.println("confirmar_senha: " + confirmar_senha);
    }
}
