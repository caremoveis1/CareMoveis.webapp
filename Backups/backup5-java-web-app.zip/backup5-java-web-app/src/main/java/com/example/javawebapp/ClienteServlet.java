package com.example.javawebapp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;



@WebServlet(name="cliente", value="/cliente")
public class ClienteServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        //Dados Pessoais Cliente
        String nome = req.getParameter("nome");
        String cpf = req.getParameter("cpf");
        String tel = req.getParameter("tel");

        //Dados de Acesso Cliente
        String email = req.getParameter("email");
        String senha = req.getParameter("senha");
        String confirmar_senha = req.getParameter("confirmar_senha");

        List<String> erros = new ArrayList<>();

        //validar nome
        if (nome == null || nome.isBlank()) {
            erros.add("O nome não pode ser vazio");
        }
        if (nome.length() < 10 || nome.length() > 80) {
            erros.add("O nome deve ter de 10 a 80 caracteres");
        }
        
        Pattern padraoNome = Pattern.compile("^[a-zA-Z ]+$");
        Matcher matcherNome = padraoNome.matcher(nome);

        if (!matcherNome.matches()) {
            erros.add("O nome deve conter apenas letras maiúsculas e minúsculas");
        }

        // //validar cpf
        if (cpf == null || cpf.isBlank()) {
            erros.add("O CPF não pode ser vazio");
        }
        if(!validateCPF(cpf)){
            erros.add("O CPF deve ser válido");
        }
       
        //validar telefone
        if (tel == null || tel.isBlank()) {
            erros.add("O telefone não pode ser vazio");
        }
        if (!validarTelefone(tel)) {
            erros.add("O telefone deve ser válido");
        }
        
        //validar email
        if (email == null || email.isBlank()) {
            erros.add("O e-mail não pode ser vazio");
        }
        
        // //validar senha
        if (senha == null || senha.isEmpty()) {
            erros.add("A senha não pode ser vazia");
        }

        if (senha.length() < 8 || senha.length() > 20) {
            erros.add("A senha deve ter de 8 a 20 caracteres");
        }

        if (!Pattern.compile("[a-z]").matcher(senha).find()) {
            erros.add("A senha deve ter pelo menos uma letra minúscula");
        }

        if (!Pattern.compile("[A-Z]").matcher(senha).find()) {
            erros.add("A senha deve ter pelo menos uma letra maiúscula");
        }

        if (!Pattern.compile("[0-9]").matcher(senha).find()) {
            erros.add("A senha deve ter pelo menos um número");
        }

        if (!verificaCaracteresEspeciais(senha)) {
            erros.add("A senha deve ter pelo menos um caracter especial");
        }
        
        // //validar confirmacao da senha
        if (confirmar_senha == null || confirmar_senha.isBlank()) {
            erros.add("A confirmação da senha não pode ser vazia");
        }
        if (senha != confirmar_senha || confirmar_senha.isEmpty()) {
            erros.add("A confirmação da senha deve ser igual a primeira senha");
        }

        if (erros.isEmpty()) {
            res.sendRedirect("home.html");
        } else {
            req.setAttribute("nome", nome);
            req.setAttribute("cpf", cpf);
            req.setAttribute("tel", tel);
            req.setAttribute("email", email);
            req.setAttribute("senha", senha);
            req.setAttribute("confirmar_senha", confirmar_senha);
            req.setAttribute("erros", erros);
            req.getRequestDispatcher("cliente.jsp").forward(req, res);
        }
    }

    public static boolean validateCPF(String cpf) {
        // Remove caracteres não numéricos
        cpf = cpf.replaceAll("[^0-9]", "");

        // Verifica se o CPF tem 11 dígitos
        if (cpf.length() != 11) {
            return false;
        }

        // Verifica se todos os dígitos são iguais (CPF inválido)
        if (cpf.matches("(\\d)\\1{10}")) {
            return false;
        }

        // Calcula o primeiro dígito verificador
        int sum = 0;
        for (int i = 0; i < 9; i++) {
            int digit = Character.getNumericValue(cpf.charAt(i));
            sum += digit * (10 - i);
        }
        int firstVerificationDigit = 11 - (sum % 11);

        if (firstVerificationDigit == 10 || firstVerificationDigit == 11) {
            firstVerificationDigit = 0;
        }

        // Verifica o primeiro dígito verificador
        if (firstVerificationDigit != Character.getNumericValue(cpf.charAt(9))) {
            return false;
        }

        // Calcula o segundo dígito verificador
        sum = 0;
        for (int i = 0; i < 10; i++) {
            int digit = Character.getNumericValue(cpf.charAt(i));
            sum += digit * (11 - i);
        }
        int secondVerificationDigit = 11 - (sum % 11);

        if (secondVerificationDigit == 10 || secondVerificationDigit == 11) {
            secondVerificationDigit = 0;
        }

        // Verifica o segundo dígito verificador
        return secondVerificationDigit == Character.getNumericValue(cpf.charAt(10));
    }

    public static boolean validarTelefone(String telefone) {
        // Remova espaços em branco e caracteres especiais
        telefone = telefone.replaceAll("\\D", "");

        // Verifique se o telefone tem exatamente 11 dígitos
        if (telefone.length() == 11) {
            // Verifique se os dois primeiros dígitos estão na faixa de códigos de área do Brasil
            String codigoArea = telefone.substring(0, 2);
            String[] codigosValidos = {
                "11", "12", "13", "14", "15", "16", "17", "18", "19", "21", "22", "24", "27", "28",
                "31", "32", "33", "34", "35", "37", "38", "41", "42", "43", "44", "45", "46", "47", "48", "49",
                "51", "53", "54", "55", "61", "62", "63", "64", "65", "66", "67", "68", "69", "71", "73", "74",
                "75", "77", "79", "81", "82", "83", "84", "85", "86", "87", "88", "89", "91", "92", "93", "94",
                "95", "96", "97", "98", "99"
            };

            for (String codigoValido : codigosValidos) {
                if (codigoArea.equals(codigoValido)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean verificaCaracteresEspeciais(String senha) {
        // Define um padrão de expressão regular para caracteres especiais
        String padrao = "[!@#$%^&*()_+{}\\[\\]:;<>,.?~\\-]";

        // Compila o padrão em um objeto Pattern
        Pattern pattern = Pattern.compile(padrao);

        // Cria um objeto Matcher para procurar o padrão na senha
        Matcher matcher = pattern.matcher(senha);

        // Retorna true se o padrão for encontrado na senha, caso contrário, retorna false
        return matcher.find();
    }
}

