package com.example.javawebapp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "transporte", value = "/transporte")
public class TransporteServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String cep = req.getParameter("cep");
        String rua = req.getParameter("rua");
        String num = req.getParameter("num");
        String compl = req.getParameter("compl");
        String cidade = req.getParameter("cidade");
        String uf = req.getParameter("uf");
     
        String cep2 = req.getParameter("cep2");
        String rua2 = req.getParameter("rua2");
        String num2 = req.getParameter("num2");
        String compl2 = req.getParameter("compl2");
        String cidade2 = req.getParameter("cidade2");
        String uf2 = req.getParameter("uf2");

        String categ = req.getParameter("categ");
        String alt = req.getParameter("alt");
        String larg = req.getParameter("larg");
        String comp = req.getParameter("comp");
        String peso = req.getParameter("peso");
        String material = req.getParameter("material");

        List<String> erros = new ArrayList<>();

        //validar cep
        validarCep(cep);
        validarCep(cep2);
        
        //validar rua
        validarRua(rua);
        validarRua(rua2);
        
        //validar numero
        validarNum(num);
        validarNum(num2);
        
        //validar complemento

        //validar cidade
        validarCidade(cidade);
        validarCidade(cidade2);
        
        //validar uf
        validarUf(uf);
        validarUf(uf2);

        //validar categoria
        if(categ==null || categ.isBlank()){
            erros.add("A categoria do móvel não pode ser vazia");
        }

        //validar altura
        if(alt==null || alt.isBlank()){
            erros.add("A altura do móvel não pode ser vazia");
        }

        try {
            float altura = Float.parseFloat(alt);
            if(altura >= 0 || altura > 4.4){
                erros.add("A altura máxima do móvel é de 4,4m");
            }
        } catch (NumberFormatException e) {
            System.err.println("Erro ao converter a string para float: " + e.getMessage());
        }

        //validar largura
        if(larg==null || larg.isBlank()){
            erros.add("A largura do móvel não pode ser vazia");
        }

        try {
            float largura = Float.parseFloat(larg);
            if(largura >= 0 || largura > 4.4){
                erros.add("A largura máxima do móvel é de 2,6m");
            }
        } catch (NumberFormatException e) {
            System.err.println("Erro ao converter a string para float: " + e.getMessage());
        }

        //validar comprimento
        if(comp==null || comp.isBlank()){
            erros.add("O comprimento do móvel não pode ser vazio");
        }

        try {
            float comprimento = Float.parseFloat(comp);
            if(comprimento >= 0 || comprimento > 4.4){
                erros.add("O comprimento máximo do móvel é de 10m");
            }
        } catch (NumberFormatException e) {
            System.err.println("Erro ao converter a string para float: " + e.getMessage());
        }

        //validar peso
        if(peso==null || peso.isBlank()){
            erros.add("O peso aproximado do móvel não pode ser vazio");
        }

        try {
            float peso2 = Float.parseFloat(peso);
            if(peso2 >= 0 || peso2 > 4.4){
                erros.add("O peso máximo do móvel é de 1000kg");
            }
        } catch (NumberFormatException e) {
            System.err.println("Erro ao converter a string para float: " + e.getMessage());
        }

        //validar material
        if(material==null || material.isBlank()){
            erros.add("O material do móvel não pode ser vazio");
        }

        if (erros.isEmpty()) {
            res.sendRedirect("estaticoCliente.html");
        } else {
            req.setAttribute("cep", cep);
            req.setAttribute("rua", rua);
            req.setAttribute("num", num);
            req.setAttribute("compl", compl);
            req.setAttribute("cidade", cidade);
            req.setAttribute("uf", uf);

            req.setAttribute("cep2", cep2);
            req.setAttribute("rua2", rua2);
            req.setAttribute("num2", num2);
            req.setAttribute("compl2", compl2);
            req.setAttribute("cidade2", cidade2);
            req.setAttribute("uf2", uf2);

            req.setAttribute("categ", categ);
            req.setAttribute("alt", alt);
            req.setAttribute("larg", larg);
            req.setAttribute("comp", comp);
            req.setAttribute("peso", peso);
            req.setAttribute("material", material);

            req.setAttribute("erros", erros);
            req.getRequestDispatcher("transporte.jsp").forward(req, res);
        }

    }

    public void validarCep(String cep){
        Pattern patternCep = Pattern.compile("\\d{5}-\\d{3}");
        Matcher matcher = patternCep.matcher(cep);
        
        if (!matcher.matches()) {
            erros.add("O CEP deve ser válido");
        }
    }

    public void validarRua(String rua){
        if (rua == null || rua.isBlank()) {
            erros.add("O nome da rua não pode ser vazio");
        }

        Pattern padraoRua = Pattern.compile("^[a-zA-Z ]+$");
        Matcher matcherRua = padraoRua.matcher(rua);

        if (!matcherRua.matches()) {
            erros.add("O nome da rua deve conter apenas letras maiúsculas e minúsculas");
        }
    }

    public void validarNum(String num){
        if (num == null || num.isBlank()) {
            erros.add("O numero da rua não pode ser vazio");
        }

        Pattern padraoNum = Pattern.compile("^[0-9]+$");
        Matcher matcherNum = padraoNum.matcher(num);

        if (!matcherNum.matches()) {
            erros.add("O numero da rua deve conter apenas numeros");
        }
    }

    public void validarCidade(String cidade){
        if (cidade == null || cidade.isBlank()) {
            erros.add("A cidade não pode ser vazia");
        }

        Pattern padraoCidade = Pattern.compile("^[A-Za-z ]+$");
        Matcher matcherCidade = padraoCidade.matcher(cidade);

        if (!matcherCidade.matches()) {
            erros.add("O nome da cidade não pode conter apenas numeros");
        }
    }

    public void validarUf(String uf){
        if (uf == null || uf.isBlank()) {
            erros.add("O estado não pode ser vazio");
        }
        if (uf.length()>2){
            erros.add("A sigla do estado deve ter duas letras");
        }
        
        Pattern padraoUF = Pattern.compile("^[A-Z]+$");
        Matcher matcherUF = padraoUF.matcher(uf);

        if (!matcherUF.matches()) {
            erros.add("A sigla do estado deve conter apenas letras maiúsculas");
        }
    }
    
}
