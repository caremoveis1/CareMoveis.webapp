package com.example.javawebapp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "login", value = "/login")
public class LoginServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        
        String email = req.getParameter("email");
        String senha = req.getParameter("senha");
       
        List<String> erros = new ArrayList<>();

        //validar email
        if (email == null || email.isBlank()) {
            erros.add("O e-mail não pode ser vazio");
        }

        // //validar senha
        if (senha == null || senha.isEmpty()) {
            erros.add("A senha não pode ser vazia");
        }

        if (senha.length() < 8 || senha.length() > 20) {
            erros.add("A senha deve ter de 8 a 20 caracteres");
        }

        if (!Pattern.compile("[a-z]").matcher(senha).find()) {
            erros.add("A senha deve ter pelo menos uma letra minúscula");
        }

        if (!Pattern.compile("[A-Z]").matcher(senha).find()) {
            erros.add("A senha deve ter pelo menos uma letra maiúscula");
        }

        if (!Pattern.compile("[0-9]").matcher(senha).find()) {
            erros.add("A senha deve ter pelo menos um número");
        }

        if (!verificaCaracteresEspeciais(senha)) {
            erros.add("A senha deve ter pelo menos um caracter especial");
        }

        if (erros.isEmpty()) {
            res.sendRedirect("estaticoCliente.html");
        } else {
            req.setAttribute("email", email);
            req.setAttribute("senha", senha);
            
            req.setAttribute("erros", erros);
            req.getRequestDispatcher("login.jsp").forward(req, res);
        }

    }

    public static boolean verificaCaracteresEspeciais(String senha) {
        // Define um padrão de expressão regular para caracteres especiais
        String padrao = "[!@#$%^&*()_+{}\\[\\]:;<>,.?~\\-]";

        // Compila o padrão em um objeto Pattern
        Pattern pattern = Pattern.compile(padrao);

        // Cria um objeto Matcher para procurar o padrão na senha
        Matcher matcher = pattern.matcher(senha);

        // Retorna true se o padrão for encontrado na senha, caso contrário, retorna false
        return matcher.find();
    }
}
