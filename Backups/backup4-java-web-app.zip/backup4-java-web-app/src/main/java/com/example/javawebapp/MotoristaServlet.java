package com.example.javawebapp;

import java.io.IOException;
import java.lang.reflect.Array;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name="motorista", value="/motorista")
public class MotoristaServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        //Dados Pessoais Motorista
        String nome = req.getParameter("nome");
        String cpf = req.getParameter("cpf");
        String tel = req.getParameter("tel");

        //Dados de Acesso Motorista
        String email = req.getParameter("email");
        String senha = req.getParameter("senha");
        String confirmar_senha = req.getParameter("confirmar_senha");

        //Dados Bancários
        String numero_conta = req.getParameter("numero_conta");
        String agencia = req.getParameter("agencia");
        String nome_titular = req.getParameter("nome_titular");
        String cpf_titular = req.getParameter("cpf_titular");
        
        //Dados da CNH
        String numero_cnh = req.getParameter("numero_cnh");
        String categoria_cnh = req.getParameter("categoria_cnh");
        String data_emissao_cnh = req.getParameter("data_emissao_cnh");
        // Date data_emissao_cnh =  new Date(req.getParameter("data_emissao_cnh"));
        String data_validade_cnh = req.getParameter("data_validade_cnh");
        //Date data_validade_cnh = new Date(req.getParameter("data_validade_cnh"));

        //Dados do Caminhão
        String marca_caminhao = req.getParameter("marca_caminhao");
        String modelo_caminhao = req.getParameter("modelo_caminhao");
        String ano_caminhao = req.getParameter("ano_caminhao");
        String placa_camihao = req.getParameter("placa_camihao");
        String tamanho = req.getParameter("chassi");

        //validar marca
        // String marca = new String("Mercedes-Benz",
        // "Volkswagen Caminhões",
        // "Scania",
        // "Volvo",
        // "Ford Caminhões",
        // "Iveco",
        // "MAN",
        // "DAF",
        // "Hino",
        // "Hyundai",
        // "Agrale",
        // "Shacman",
        // "JMC",
        // "Sinotruk",
        // "Foton",
        // "Jac Motors",
        // "International",
        // "Kenworth");
        //validar modelo
        //validaar ano
        //validar placa
        //validar tamanho

        // salvar no banco de dados
        // enviar um email para o admin com a mensagem

        // System.out.println("nome: " + nome);
        // System.out.println("cpf: " + cpf);
        // System.out.println("telefone: " + tel);

        // System.out.println("email: " + email);
        // System.out.println("senha: " + senha);
        // System.out.println("confirmar_senha: " + confirmar_senha);

        // System.out.println("numero_conta: " + numero_conta);
        // System.out.println("agencia: " + agencia);
        // System.out.println("nome_titular: " + nome_titular);
        // System.out.println("cpf_titular: " + cpf_titular);

        // System.out.println("numero_cnh: " + numero_cnh);
        // System.out.println("categoria_cnh: " + categoria_cnh);
        // System.out.println("data_emissao_cnh: " + data_emissao_cnh);
        // System.out.println("data_validade_cnh: " + data_validade_cnh);

        // System.out.println("marca_caminhao: " + marca_caminhao);
        // System.out.println("modelo_caminhao: " + modelo_caminhao);
        // System.out.println("ano_caminhao: " + ano_caminhao);
        // System.out.println("placa_camihao: " + placa_camihao);
        // System.out.println("chassi: " + chassi);


    }
}
