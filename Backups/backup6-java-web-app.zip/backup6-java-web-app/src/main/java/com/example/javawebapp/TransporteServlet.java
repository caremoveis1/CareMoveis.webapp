package com.example.javawebapp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "transporte", value = "/transporte")
public class TransporteServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String cep = req.getParameter("cep");
        String rua = req.getParameter("rua");
        String num = req.getParameter("num");
        String compl = req.getParameter("compl");
        String cidade = req.getParameter("cidade");
        String uf = req.getParameter("uf");
     
        String cep2 = req.getParameter("cep2");
        String rua2 = req.getParameter("rua2");
        String num2 = req.getParameter("num2");
        String compl2 = req.getParameter("compl2");
        String cidade2 = req.getParameter("cidade2");
        String uf2 = req.getParameter("uf2");

        String categ = req.getParameter("categ");
        String alt = req.getParameter("alt");
        String larg = req.getParameter("larg");
        String peso = req.getParameter("peso");
        String material = req.getParameter("material");

        List<String> erros = new ArrayList<>();

        //validar cep
        //validar rua
        if (rua == null || rua.isBlank()) {
            erros.add("O nome da rua não pode ser vazio");
        }

        Pattern padraoRua = Pattern.compile("^[a-zA-Z ]+$");
        Matcher matcherRua = padraoRua.matcher(rua);

        if (!matcherRua.matches()) {
            erros.add("O nome da rua deve conter apenas letras maiúsculas e minúsculas");
        }

        //validar numero
        if (num == null || num.isBlank()) {
            erros.add("O numero da rua não pode ser vazio");
        }

        Pattern padraoNum = Pattern.compile("^[0-9]+$");
        Matcher matcherNum = padraoNum.matcher(num);

        if (!matcherNum.matches()) {
            erros.add("O numero da rua deve conter apenas numeros");
        }

        //validar complemento

        //validar cidade

        //validar uf
        if (num == null || num.isBlank()) {
            erros.add("O estado não pode ser vazio");
        }
        if (uf.length()>2){
            erros.add("A sigla do estado deve ter duas letras");
        }
        
        Pattern padraoUF = Pattern.compile("^[A-Z]+$");
        Matcher matcherUF = padraoUF.matcher(uf);

        if (!matcherUF.matches()) {
            erros.add("A sigla do estado deve conter apenas letras maiúsculas");
        }
    }
}
